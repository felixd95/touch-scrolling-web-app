import json
from typing import Any, Dict

REQUIRED_KEYS = (
    "scrollFriction",
    "x1",
    "x2",
    "inflexion",
    "physicalCoeffTuning",
    "maxLaunchVelocityPxMs",
)


def model_fn(model_dir: str) -> Dict[str, Any]:
    # No persisted model artifact is required for this lightweight online policy.
    return {}


def input_fn(request_body: str, request_content_type: str) -> Dict[str, Any]:
    if request_content_type != "application/json":
        raise ValueError(f"Unsupported content type: {request_content_type}")

    payload = json.loads(request_body)
    if not isinstance(payload, dict):
        raise ValueError("Payload must be a JSON object")

    return payload


def _normalize_current_params(payload: Dict[str, Any]) -> Dict[str, float]:
    candidate = payload.get("currentParameterSet", {})
    if not isinstance(candidate, dict):
        candidate = {}

    defaults = {
        "scrollFriction": 0.015,
        "x1": 0.78,
        "x2": 0.9,
        "inflexion": 0.35,
        "physicalCoeffTuning": 0.84,
        "maxLaunchVelocityPxMs": 40.0,
    }

    normalized = {}
    for key in REQUIRED_KEYS:
        value = candidate.get(key, defaults[key])
        try:
            normalized[key] = float(value)
        except (TypeError, ValueError):
            normalized[key] = float(defaults[key])

    return normalized


def predict_fn(input_data: Dict[str, Any], model: Dict[str, Any]) -> Dict[str, Any]:
    # Baseline policy: raise each parameter by 10% after each completed block.
    # This interface is compatible with replacing this logic by a full Bayesian optimizer.
    current = _normalize_current_params(input_data)

    next_params = {key: value * 1.1 for key, value in current.items()}

    return {
        "parameters": next_params,
        "modelMetadata": {
            "strategy": "active-learning-bayesian-placeholder",
            "version": "v1",
        },
    }


def output_fn(prediction: Dict[str, Any], accept: str) -> str:
    if accept not in ("application/json", "*/*"):
        raise ValueError(f"Unsupported accept type: {accept}")

    return json.dumps(prediction)
